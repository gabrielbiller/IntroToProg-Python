# ------------------------------------------------- #
# Title: Functions and Classes (Assignment 06)
# Dev:   GBiller
# Date:  May 7, 2018
# ChangeLog: (Who, When, What)
#   RRoot, 11/02/2016, Created starting template
#   GBiller, 04/30/2018, Added code to complete assignment 5
#   GBiller, 05/07/2018, Re-organized and modified code to
#                        complete assignment 6
# ------------------------------------------------- #

# -- Data -- #
# Declare variables and constants
strFileName = "ToDo.txt"    # A string that represents the name of the text file
strData = ""                # A row of text data from the file
dicRow = {}                 # A row of data separated into elements of a dictionary
lstTable = []               # A list of dictionaries that acts as a 'table' of rows
MENU = """
    Menu of options:

    C - Show current data
    A - Add a new item
    R - Remove an existing item
    S - Save data to file
    E - Exit program
    """                     # A menu of user options
strChoice = ""              # Capture the user option selection

# -- Processing -- #
# -- Make the class ToDoList -- #
class ToDoList(object):
    # -- Functions/Methods -- #
    # Define a function that loops through the list of dictionaries (list/table)
    # and re-numbers the Task IDs 1, 2, 3, etc.
    @staticmethod
    def reNumberTaskIDs():
        i = 1
        for d in lstTable:
            d["ID"] = i
            i += 1

    # Define a function that loads each 'row' of data in 'ToDo.txt' into a
    # Python dictionary. Then, add each dictionary 'row' to a Python list 'table.'
    @staticmethod
    def loadDataFromFile():
        f = open(strFileName, "r")  # create file object
        intCounter = 1              # for assigning IDs to tasks
        while True:
            strData = f.readline().strip()  # read one line at a time
            if not strData: break           # break if at end of file
            # unpack, split on last comma in case task description has commas
            task, priority = strData.rsplit(",", 1)
            dicRow = {"ID": intCounter, "Task": task, "Priority": priority}
            lstTable.append(dicRow)
            intCounter += 1
        f.close()                   # close the file (done reading)

    # Define a function that displays the current contents of the list/table
    # to the user
    @staticmethod
    def showCurrentItems():
        if len(lstTable) == 0:
            print("There are no current data to show.")
        else:
            print("#. TASK (PRIORITY)")     # print header row
            print("------------------")
            for d in lstTable:              # iterate through dictionary items
                print(str(d["ID"]) + ". " + d["Task"] + " (" + d["Priority"] + ")")

    # Define a function that allows the user to add a new item to the list/table
    @staticmethod
    def addNewItem():
        strTask = input("Task: ").strip()
        while True:
            strPriority = input("Priority (low/med/high): ").strip().lower()
            if strPriority in ("low", "med", "high"): break
            else: print("Invalid entry!")
        lstTable.append({"ID": len(lstTable) + 1, "Task": strTask, \
                         "Priority": strPriority})

    # Define a function that allows the user to remove an existing item
    # from the list/table
    @staticmethod
    def removeItem():
        strTaskID = input("Which task do you wish to remove? (enter #) ").strip()
        try:
            intTaskID = int(strTaskID)
            blnFound = False            # initialize Boolean for finding the Task ID
            for d in lstTable:
                if intTaskID == d["ID"]:
                    blnFound = True
                    del lstTable[intTaskID - 1]     # delete dict obj from list/table
                    ToDoList.reNumberTaskIDs()      # re-number the Task IDs
                    print("\nTask #" + str(intTaskID) + " successfully removed!")
                    break
            # if valid int entered, but not found in list/table, print error message
            if not blnFound: print("\nTask #" + str(intTaskID) + " not found.")
        except ValueError:
            print("\nTask #" + str(strTaskID) + " not found.")

    # Define a function that saves the tasks in the list/table to the 'ToDo.txt' file
    @staticmethod
    def saveDataToFile():
        f = open(strFileName, "w")
        for d in lstTable:
            f.write(d["Task"] + "," + d["Priority"] + "\n")
        f.close()
        print("Data successfully saved to file " + strFileName + "!")

# Step 1 - Load data from a file
ToDoList.loadDataFromFile()

# -- Presentation (Input/Output) -- #
# Step 2 - Display a menu of choices to the user
while True:
    print(MENU)
    strChoice = input("Which option would you like to perform? ").strip().upper()
    print()     # adding a new line

    # Step 3 - Show the current items in the table
    if strChoice == "C":
        ToDoList.showCurrentItems()
    # Step 4 - Add a new item to the list/table
    elif strChoice == "A":
        ToDoList.addNewItem()
    # Step 5 - Remove an existing item from the list/table
    elif strChoice == "R":
        ToDoList.removeItem()
    # Step 6 - Save tasks to the 'ToDo.txt' file
    elif strChoice == "S":
        ToDoList.saveDataToFile()
    # Step 7 - Exit program
    elif strChoice == "E":
        print("Goodbye!")
        break
    # Some unknown choice
    else:
        print("Sorry, but", strChoice, "isn't a valid choice.")